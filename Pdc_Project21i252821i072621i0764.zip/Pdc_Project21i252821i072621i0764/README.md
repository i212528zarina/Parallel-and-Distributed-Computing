
# Parallel Dijkstra's Algorithm Implementation with MPI
Dijkstra's algorithm is a graph traversal algorithm used to find the shortest path between nodes in a graph with non-negative edge weights. This project implements Dijkstra's algorithm in a parallel fashion using the Message Passing Interface (MPI) for distributed memory systems. By distributing the workload across multiple processes, the algorithm can be executed more efficiently, particularly for large graphs.
# Features
### Parallel Execution:
The algorithm is parallelized using MPI to distribute the computation across multiple processes, allowing for faster execution on parallel and distributed systems.
### Undirected Graphs:
 The implementation supports undirected graphs, where each edge connects two nodes bidirectionally.
### Customizable Input Graph:
 Users can provide their own input graph file in a specified format, allowing for flexibility in testing different graphs.

# Compilation and Execution
## compile:
1- Ensure MPI is installed on your system. If not, install MPI using your package manager or download it from the MPI website.
2- Navigate to the directory containing the source code.
3- Compile the code using mpicc (MPI C compiler) and specify the appropriate flags:
#### mpicc -o dijkstra_mpi dijkstra_mpi.c

## Execution:
Run the MPI executable with the desired input graph file:
#### mpirun -np <num_processes> ./dijkstra_mpi <graph_file>
Replace <num_processes> with the number of MPI processes you want to use, and <graph_file> with the path to your input graph file.

# Performance Measurement
The execution time for each MPI process will be printed at the end of the program, allowing for performance analysis and optimization.

# Notes
This implementation assumes an undirected graph.
The default weight for each edge is set to 1. Modify the code if your graph has different edge weights.
