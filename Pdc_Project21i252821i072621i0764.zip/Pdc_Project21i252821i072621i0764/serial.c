#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <time.h>

#define MAX_NODES 1000 // Maximum number of nodes
#define MAX_LINE_LENGTH 1000 // Maximum length of a line in the file

typedef struct Node {
    int id;
    char name[MAX_LINE_LENGTH];
    struct Edge *next;
} Node;

typedef struct Edge {
    int target;
    int weight;
    struct Edge *next;
} Edge;

int numNodes = 0;
Node nodes[MAX_NODES];
Edge *adjacencyList[MAX_NODES]; // Array of pointers to edges

int getOrCreateNodeId(char *nodeName) {
    for (int i = 0; i < numNodes; i++) {
        if (strcmp(nodes[i].name, nodeName) == 0) {
            return nodes[i].id;
        }
    }
    // Node not found, create a new node
    nodes[numNodes].id = numNodes;
    strcpy(nodes[numNodes].name, nodeName);
    adjacencyList[numNodes] = NULL; // Initialize adjacency list for the new node
    return numNodes++;
}

void addEdgeToList(Edge **list, int target, int weight) {
    Edge *newEdge = (Edge *)malloc(sizeof(Edge));
    newEdge->target = target;
    newEdge->weight = weight;
    newEdge->next = *list;
    *list = newEdge;
}

void read_graph_from_file(char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file %s.\n", filename);
        exit(1);
    }

    char line[MAX_LINE_LENGTH];
    fgets(line, MAX_LINE_LENGTH, file); // Skip the header line

    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        char source[MAX_LINE_LENGTH], target[MAX_LINE_LENGTH];
        int weight;
        sscanf(line, "%[^,],%[^,],%d", source, target, &weight);

        int sourceId = getOrCreateNodeId(source);
        int targetId = getOrCreateNodeId(target);

        addEdgeToList(&adjacencyList[sourceId], targetId, weight);
        // For undirected graph, add the reverse edge as well
        addEdgeToList(&adjacencyList[targetId], sourceId, weight);
    }

    fclose(file);
}

void print_adjacency_list() {
    for (int i = 0; i < numNodes; i++) {
        printf("Node %d (%s): ", i, nodes[i].name);
        Edge *edge = adjacencyList[i];
        while (edge != NULL) {
            printf("(%d, %d) ", edge->target, edge->weight);
            edge = edge->next;
        }
        printf("\n");
    }
}

void dijkstra(int source, int destination) {
    int dist[MAX_NODES];
    int prev[MAX_NODES];
    int visited[MAX_NODES] = {0};

    for (int i = 0; i < numNodes; i++) {
        dist[i] = INT_MAX;
        prev[i] = -1;
    }

    dist[source] = 0;

    for (int count = 0; count < numNodes; count++) {
        int minDist = INT_MAX, minIndex;

        // Find the node with the minimum distance
        for (int v = 0; v < numNodes; v++) {
            if (!visited[v] && dist[v] < minDist) {
                minDist = dist[v];
                minIndex = v;
            }
        }

        int u = minIndex;
        visited[u] = 1;

        Edge *edge = adjacencyList[u];
        while (edge != NULL) {
            int v = edge->target;
            int weight = edge->weight;
            if (!visited[v] && dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                prev[v] = u;
            }
            edge = edge->next;
        }
    }

    // Print the shortest distance and path
    if (dist[destination] == INT_MAX) {
        printf("No path from node %s to node %s\n", nodes[source].name, nodes[destination].name);
    } else {
        printf("Shortest distance from node %s to node %s: %d\n", nodes[source].name, nodes[destination].name, dist[destination]);

        // Print path
        printf("Path: ");
        int currentNode = destination;
        while (currentNode != -1) {
            printf("%s", nodes[currentNode].name);
            currentNode = prev[currentNode];
            if (currentNode != -1)
                printf(" <- ");
        }
        printf("\n");
    }
}

int main() {
    char filename[] = "doctorwho.csv";
    read_graph_from_file(filename);

    printf("Adjacency List:\n");
    print_adjacency_list();

    // Example usage: find shortest path from node 0 to node 14
    int sourceNode = 0;
    int destinationNode = 14;
        // Start timing
    clock_t start_time = clock();

    dijkstra(sourceNode, destinationNode);

 clock_t end_time = clock();
 double execution_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;

    printf("Execution time: %.6f seconds\n", execution_time);


    return 0;
}

